﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace WS.Suma.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OperacionController : ControllerBase
    {
        [HttpGet()]
        public ActionResult<int> Operar(int numero1, int numero2)
        {
            return numero1 + numero2;
        }

    }
}