﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win.Calculadora
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Operar(string pOperacion)
        {
            if (string.IsNullOrEmpty(TxtNumero1.Text) || string.IsNullOrEmpty(TxtNumero2.Text))
            {
                MessageBox.Show("Datos no pueden estar en blanco", "Mensaje de validacion", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!int.TryParse(TxtNumero1.Text,out int numero1) || !int.TryParse(TxtNumero2.Text, out int numero2))
            {
                MessageBox.Show("Datos numericos invalidos", "Mensaje de validacion", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            ConsumirWS(pOperacion);
        }

        private void ConsumirWS(string pOperacion)
        {            
            HttpWebRequest request = WebRequest.Create(
                string.Format("http://localhost:51340/api/Gateway/?numero1={0}&numero2={1}&operador={2}", TxtNumero1.Text, TxtNumero2.Text, pOperacion)) as HttpWebRequest;
            request.Method = "GET";
            request.ContentType = "application/json;charset=UTF-8";            

            try
            {
                HttpWebResponse response = request.GetResponse() as HttpWebResponse;
                using (StreamReader reader = new StreamReader(response.GetResponseStream()))
                {
                    TxtResultado.Text = reader.ReadToEnd();
                }
            }
            catch (WebException ex)
            {
                using (StreamReader reader = new StreamReader(ex.Response.GetResponseStream()))
                {
                    MessageBox.Show(reader.ReadToEnd());                    
                }
            }


        }




        private void BtnSuma_Click(object sender, EventArgs e)
        {           
            Operar("1");
        }

        private void BtnResta_Click(object sender, EventArgs e)
        {
            Operar("2");
        }

        private void BtnDiv_Click(object sender, EventArgs e)
        {
            Operar("3");
        }

        private void BtnMul_Click(object sender, EventArgs e)
        {
            Operar("4");
        }
    }
}
