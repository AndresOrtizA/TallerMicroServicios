﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ApiGateway.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GatewayController : ControllerBase
    {        
        [HttpGet()]
        public ActionResult<string> Operar(int numero1, int numero2, string operador)
        {
            string url = "";
            switch (operador)
            {
                // +
                case "1":
                    url = "51244";
                    break;
                // -
                case "2":
                    url = "51286";
                    break;
                // /
                case "3":
                    url = "51295";
                    break;
                // *
                case "4":
                    url = "51305";
                    break;
                default:
                    break;
            }

            if (string.IsNullOrEmpty(url))
            {
                return BadRequest();
            }

            HttpWebRequest request = WebRequest.Create(
                string.Format("http://localhost:{0}/api/Operacion/?numero1={1}&numero2={2}",
                url,
                numero1, 
                numero2)) as HttpWebRequest;
            request.Method = "GET";
            request.ContentType = "application/json;charset=UTF-8";

            try
            {
                HttpWebResponse response = request.GetResponse() as HttpWebResponse;
                using (StreamReader reader = new StreamReader(response.GetResponseStream()))
                {
                    return reader.ReadToEnd();
                }
            }
            catch (WebException ex)
            {
                using (StreamReader reader = new StreamReader(ex.Response.GetResponseStream()))
                {
                    return StatusCode((int)HttpStatusCode.InternalServerError,reader.ReadToEnd());                    
                }
            }
            
        }

    }

}